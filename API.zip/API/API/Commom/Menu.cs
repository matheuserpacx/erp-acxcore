﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace API.Common
{
    public class Menu
    {
        public string strMenu = "{\"Menu\":[{\"nome\":'',\"href\":'',\"objmenu\":{\"class_icon\":'',\"icon\":'',\"class_menu_item\":'',\"class_menu_list\":''},\"submenulist\":[{\"nome\":'',\"href\":'',\"objmenu\":{\"class_icon\":'',\"icon\":'',\"class_menu_item\":'',\"class_menu_list\":''},\"submenulist\":[]},{\"nome\":'',\"href\":'',\"objmenu\":{\"class_icon\":'',\"icon\":'',\"class_menu_item\":'',\"class_menu_list\":''},\"submenulist\":[]},{\"nome\":'',\"href\":'',\"objmenu\":{\"class_icon\":'',\"icon\":'',\"class_menu_item\":'',\"class_menu_list\":''},\"submenulist\":[{\"nome\":'',\"href\":'',\"objmenu\":{\"class_icon\":'',\"icon\":'',\"class_menu_item\":'',\"class_menu_list\":''},\"submenulist\":[]}]}]}]}";
    }
}